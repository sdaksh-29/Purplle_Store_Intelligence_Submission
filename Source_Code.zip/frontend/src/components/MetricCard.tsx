"use client";

import { motion } from "framer-motion";
import { Users, TrendingUp, Clock, Activity, Target, Zap } from "lucide-react";
import { cn } from "@/lib/utils";

interface MetricCardProps {
  title: string;
  value: string | number;
  icon: React.ElementType;
  trend?: string;
  trendUp?: boolean;
  delay?: number;
  className?: string;
}

export function MetricCard({ title, value, icon: Icon, trend, trendUp, delay = 0, className }: MetricCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
      className={cn("glass-card p-6 relative overflow-hidden group hover:border-purplle-500/50 transition-colors", className)}
    >
      <div className="absolute -right-4 -top-4 opacity-5 group-hover:opacity-10 transition-opacity">
        <Icon className="w-32 h-32" />
      </div>
      
      <div className="flex justify-between items-start mb-4">
        <h3 className="text-slate-400 font-medium text-sm">{title}</h3>
        <div className="p-2 bg-purplle-500/10 rounded-lg">
          <Icon className="w-5 h-5 text-purplle-400" />
        </div>
      </div>
      
      <div className="flex items-baseline space-x-2">
        <h2 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-white to-slate-400">
          {value}
        </h2>
        {trend && (
          <span className={cn(
            "text-xs font-semibold px-2 py-1 rounded-full",
            trendUp ? "bg-emerald-500/10 text-emerald-400" : "bg-rose-500/10 text-rose-400"
          )}>
            {trendUp ? "↑" : "↓"} {trend}
          </span>
        )}
      </div>
    </motion.div>
  );
}
