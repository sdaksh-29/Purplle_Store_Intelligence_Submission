import cv2
import json
from datetime import datetime
from pathlib import Path
from app.cv.pipeline import CameraPipeline
from app.services.session import SessionManager
from app.schemas.event import CameraType

class EventReplayTester:
    def __init__(self, video_path: str, camera_id: str, camera_type: CameraType, zones_config: dict):
        self.video_path = video_path
        self.pipeline = CameraPipeline(camera_id, camera_type)
        self.pipeline.setup_zones(zones_config)
        self.session_manager = SessionManager()
        
    def run(self, output_json: str = "events.json"):
        cap = cv2.VideoCapture(self.video_path)
        fps = cap.get(cv2.CAP_PROP_FPS)
        frame_count = 0
        all_events = []
        
        # Simulate real-time by incrementing timestamp by 1/fps
        start_time = datetime.utcnow()
        
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break
                
            current_time = start_time + __import__('datetime').timedelta(seconds=frame_count / fps)
            events = self.pipeline.process_frame(frame, current_time, self.session_manager)
            
            for event in events:
                event_dict = event.model_dump()
                event_dict['timestamp'] = event_dict['timestamp'].isoformat()
                event_dict['event_id'] = str(event_dict['event_id'])
                all_events.append(event_dict)
                print(f"Generated Event: {event_dict['event_type']} for visitor {event_dict['visitor_id']}")
                
            frame_count += 1
            
        cap.release()
        
        with open(output_json, 'w') as f:
            json.dump(all_events, f, indent=2)
            
        print(f"Replay finished. {len(all_events)} events generated and saved to {output_json}")

if __name__ == "__main__":
    # Example usage
    zones = {
        "billing_queue": [(100, 100), (300, 100), (300, 400), (100, 400)],
        "exit_zone": [(500, 400), (600, 400), (600, 500), (500, 500)]
    }
    
    # tester = EventReplayTester("sample_cctv.mp4", "cam_01", CameraType.ENTRY_CAMERA, zones)
    # tester.run()
