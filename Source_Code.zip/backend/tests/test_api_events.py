"""
PROMPT:
Generate comprehensive tests. Test: Invalid Events, Duplicate Events, API Failures, Database Failure. Every test file must contain PROMPT and CHANGES MADE.

CHANGES MADE:
- Created test suite for POST /events/ingest API.
- Added tests for Pydantic schema validation failures (Invalid Events).
- Added tests for EventValidator deduplication logic (Duplicate Events).
- Added tests for HTTP 413 Payload Too Large (API Failures).
- Added tests for Database repository fallback handling (Database Failure).
"""

import pytest
from fastapi.testclient import TestClient
from unittest.mock import patch, MagicMock
from app.main import app
from app.schemas.event import StoreEvent, EventType, CameraType
from app.services.event_validator import validator

client = TestClient(app)

def test_ingest_valid_events():
    event = StoreEvent(
        visitor_id="123e4567-e89b-12d3-a456-426614174000",
        event_type=EventType.ENTRY,
        camera_id="cam_01",
        camera_type=CameraType.ENTRY_CAMERA,
        confidence=0.95
    )
    # Ensure fresh state for validator
    validator._seen_events.clear()
    
    response = client.post("/events/ingest", json=[json.loads(event.model_dump_json())])
    assert response.status_code == 202
    assert response.json()["accepted"] == 1
    assert response.json()["rejected"] == 0

def test_ingest_duplicate_events():
    event = StoreEvent(
        visitor_id="duplicate-uuid",
        event_type=EventType.ZONE_ENTER,
        camera_id="cam_01",
        camera_type=CameraType.MAIN_FLOOR_CAMERA,
        confidence=0.90,
        metadata={"zone": "Skincare"}
    )
    validator._seen_events.clear()
    
    # Send same event twice
    payload = [json.loads(event.model_dump_json()), json.loads(event.model_dump_json())]
    response = client.post("/events/ingest", json=payload)
    
    assert response.status_code == 202
    assert response.json()["accepted"] == 1
    assert response.json()["rejected"] == 1
    assert "rejected" in response.json()["errors"][0].lower()

def test_ingest_invalid_events():
    invalid_payload = [{
        "visitor_id": "123",
        "event_type": "NOT_A_REAL_EVENT", # Invalid enum
        "camera_id": "cam_01",
        "camera_type": "ENTRY_CAMERA",
        "confidence": 1.5 # Invalid confidence (>1.0)
    }]
    
    response = client.post("/events/ingest", json=invalid_payload)
    assert response.status_code == 422 # Pydantic validation error

def test_api_failure_payload_too_large():
    # Max batch is 500. Let's send 501.
    event = StoreEvent(
        visitor_id="123",
        event_type=EventType.ENTRY,
        camera_id="cam_01",
        camera_type=CameraType.ENTRY_CAMERA,
        confidence=0.9
    )
    payload = [json.loads(event.model_dump_json())] * 501
    
    response = client.post("/events/ingest", json=payload)
    assert response.status_code == 413
    assert "exceeds maximum" in response.json()["detail"]

@patch("app.db.repository.EventRepository.add")
def test_database_failure_handling(mock_add):
    # Simulate DB/Repository throwing an error when adding
    mock_add.side_effect = Exception("DB Connection Lost")
    
    event = StoreEvent(
        visitor_id="123",
        event_type=EventType.ENTRY,
        camera_id="cam_01",
        camera_type=CameraType.ENTRY_CAMERA,
        confidence=0.9
    )
    
    validator._seen_events.clear()
    
    # Ingest should still accept because DB write is decoupled/async, 
    # but the internal exception shouldn't crash the API
    response = client.post("/events/ingest", json=[json.loads(event.model_dump_json())])
    assert response.status_code == 202
    assert response.json()["accepted"] == 1
