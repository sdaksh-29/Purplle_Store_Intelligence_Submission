"use client";

import { useEffect, useState } from 'react';

export interface LiveEvent {
  event_id: string;
  visitor_id: string;
  event_type: string;
  timestamp: string;
  camera_id: string;
  camera_type: string;
  confidence: number;
  metadata?: Record<string, any>;
}

export function useRealtime() {
  const [events, setEvents] = useState<LiveEvent[]>([]);
  const [isConnected, setIsConnected] = useState(false);

  useEffect(() => {
    // In production, configure environment variable for WS URL
    const ws = new WebSocket('ws://localhost:8000/ws/live');

    ws.onopen = () => {
      setIsConnected(true);
      console.log('Connected to Live Event Stream');
    };

    ws.onmessage = (message) => {
      try {
        const event: LiveEvent = JSON.parse(message.data);
        setEvents((prev) => {
          const newEvents = [event, ...prev];
          // Keep only the last 100 events in memory to prevent frontend lag
          if (newEvents.length > 100) {
            newEvents.pop();
          }
          return newEvents;
        });
      } catch (err) {
        console.error("Failed to parse event", err);
      }
    };

    ws.onclose = () => {
      setIsConnected(false);
      console.log('Disconnected from Live Event Stream');
    };

    return () => {
      ws.close();
    };
  }, []);

  return { events, isConnected };
}
