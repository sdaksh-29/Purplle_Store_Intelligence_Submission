"use client";

import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Sparkles, AlertTriangle, Info, ArrowRight } from "lucide-react";
import { cn } from "@/lib/utils";

export function AIInsightsPanel() {
  const [insights, setInsights] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("http://localhost:8000/stores/store_1/insights/comprehensive")
      .then(res => res.json())
      .then(data => {
        // Map the backend severity/categories to visual types
        const mapped = data.insights.map((i: any, idx: number) => ({
          id: idx,
          type: i.severity === "CRITICAL" ? "CRITICAL" : i.severity === "WARNING" ? "WARN" : "INFO",
          text: i.insight_text,
          action: i.suggested_action || "Investigate"
        }));
        setInsights(mapped);
        setLoading(false);
      })
      .catch(err => {
        console.error("Failed to load insights", err);
        setLoading(false);
      });
  }, []);

  if (loading) return <div className="glass-card p-6 animate-pulse">Loading AI Insights...</div>;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.5 }}
      className="glass-card p-6 col-span-full"
    >
      <div className="flex items-center space-x-2 mb-6">
        <Sparkles className="w-6 h-6 text-purplle-400 animate-pulse" />
        <h2 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purplle-400 to-pink-400">
          Live AI Insights Engine
        </h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {insights.slice(0,3).map((insight, idx) => (
          <motion.div
            key={insight.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.6 + (idx * 0.1) }}
            className={cn(
              "p-4 rounded-xl border relative overflow-hidden",
              insight.type === "CRITICAL" ? "bg-rose-500/10 border-rose-500/30" : 
              insight.type === "WARN" ? "bg-amber-500/10 border-amber-500/30" : 
              "bg-blue-500/10 border-blue-500/30"
            )}
          >
            <div className="flex items-start gap-3">
              {insight.type === "CRITICAL" ? <AlertTriangle className="w-5 h-5 text-rose-400 mt-1 flex-shrink-0" /> : <Info className="w-5 h-5 text-blue-400 mt-1 flex-shrink-0" />}
              <div>
                <p className="text-sm text-slate-200 mb-3">{insight.text}</p>
                <button className="text-xs font-semibold px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 transition-colors flex items-center gap-1">
                  {insight.action} <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}
