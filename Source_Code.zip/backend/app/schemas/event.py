from enum import Enum
from pydantic import BaseModel, Field
from typing import Optional, Dict, Any
from datetime import datetime
from uuid import UUID, uuid4

class EventType(str, Enum):
    ENTRY = "ENTRY"
    EXIT = "EXIT"
    ZONE_ENTER = "ZONE_ENTER"
    ZONE_EXIT = "ZONE_EXIT"
    ZONE_DWELL = "ZONE_DWELL"
    BILLING_QUEUE_JOIN = "BILLING_QUEUE_JOIN"
    BILLING_QUEUE_ABANDON = "BILLING_QUEUE_ABANDON"
    REENTRY = "REENTRY"

class CameraType(str, Enum):
    ENTRY_CAMERA = "ENTRY_CAMERA"
    MAIN_FLOOR_CAMERA = "MAIN_FLOOR_CAMERA"
    BILLING_CAMERA = "BILLING_CAMERA"

class PersonAttribute(BaseModel):
    is_staff: bool = False
    confidence: float = 0.0

class StoreEvent(BaseModel):
    event_id: UUID = Field(default_factory=uuid4)
    visitor_id: str = Field(..., description="Unique ID for the tracked person across cameras")
    event_type: EventType
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    camera_id: str
    camera_type: CameraType
    confidence: float = Field(..., ge=0.0, le=1.0)
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Zone name, dwell time, etc.")

    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }
