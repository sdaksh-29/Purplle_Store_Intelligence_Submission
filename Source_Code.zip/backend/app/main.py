from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import asyncio

from app.api.endpoints import events, analytics, health
from app.core.bus import event_bus
from app.db.repository import event_repository
from app.schemas.event import StoreEvent

app = FastAPI(
    title="Purplle Store Intelligence API",
    description="Production-grade API for real-time CCTV store analytics.",
    version="1.0.0",
    docs_url="/docs",    # Swagger UI
    redoc_url="/redoc"   # ReDoc
)

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Connect Event Bus to Repository (for persistent storage)
async def process_event_for_storage(event: StoreEvent):
    """Callback function subscribed to the event bus that persists events"""
    await event_repository.add(event)

from app.api.endpoints import insights, ws
app.include_router(insights.router, prefix="/stores", tags=["AI Insights"])
app.include_router(ws.router, prefix="/ws", tags=["Real-time"])

@app.on_event("startup")
async def startup_event():
    # Start subscribing to the event bus when the app starts
    await event_bus.subscribe("store_events", process_event_for_storage)
    ws.setup_ws_broadcaster()
    print("Store Intelligence System started. Subscribed to Event Bus.")

@app.on_event("shutdown")
async def shutdown_event():
    # Flush remaining events to DB before shutting down
    await event_repository.flush()
    print("Store Intelligence System shutting down. Buffer flushed.")

# Include base routers
app.include_router(events.router, prefix="/events", tags=["Events"])
app.include_router(analytics.router, prefix="/stores", tags=["Analytics"])
app.include_router(health.router, prefix="/health", tags=["System"])
