"use client";

import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Trophy } from "lucide-react";

export function Leaderboard() {
  const [data, setData] = useState<any[]>([]);

  useEffect(() => {
    fetch("http://localhost:8000/stores/store_1/heatmap")
      .then(res => res.json())
      .then(resData => {
        // Sort zones by dwell time descending to create a leaderboard
        const sorted = Object.entries(resData.zone_dwells)
          .map(([zone, dwell]: [string, any]) => ({
            zone,
            score: Math.round(dwell * 10), // arbitrary point calculation
            metric: `${Math.round(dwell)}m avg dwell`,
            trend: "+0%"
          }))
          .sort((a, b) => b.score - a.score)
          .slice(0, 4);
        
        setData(sorted.length ? sorted : [
          { zone: "No data yet", score: 0, metric: "0m", trend: "0%" }
        ]);
      })
      .catch(console.error);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5, delay: 0.3 }}
      className="glass-card p-6 col-span-full lg:col-span-1"
    >
      <div className="flex items-center space-x-3 mb-6">
        <Trophy className="w-6 h-6 text-yellow-400" />
        <h2 className="text-xl font-bold">Top Performing Zones</h2>
      </div>

      <div className="space-y-4">
        {data.map((item, idx) => (
          <motion.div
            key={item.zone + idx}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 + idx * 0.1 }}
            className="flex items-center justify-between p-3 rounded-xl bg-white/5 border border-white/5 hover:bg-white/10 transition-colors cursor-default relative overflow-hidden"
          >
            {idx === 0 && (
              <div className="absolute inset-0 bg-gradient-to-r from-yellow-500/10 to-transparent pointer-events-none" />
            )}
            <div className="flex items-center space-x-4">
              <div className="w-8 h-8 rounded-full bg-purplle-500/20 flex items-center justify-center font-bold text-purplle-300">
                #{idx + 1}
              </div>
              <div>
                <p className="font-semibold">{item.zone}</p>
                <p className="text-xs text-slate-400">{item.metric}</p>
              </div>
            </div>
            
            <div className="text-right">
              <div className="font-bold text-purplle-400">{item.score} pts</div>
              <div className="text-xs text-emerald-400">{item.trend}</div>
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}
