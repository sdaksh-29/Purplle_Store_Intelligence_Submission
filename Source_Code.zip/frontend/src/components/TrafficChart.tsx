"use client";

import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

export function TrafficChart() {
  const [data, setData] = useState<any[]>([]);

  useEffect(() => {
    fetch("http://localhost:8000/stores/store_1/traffic_trends")
      .then(res => res.json())
      .then(d => setData(d))
      .catch(console.error);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.6 }}
      className="glass-card p-6 h-[400px] col-span-full lg:col-span-2 flex flex-col"
    >
      <div className="mb-4">
        <h2 className="text-xl font-bold">Traffic & Conversion Trends</h2>
        <p className="text-sm text-slate-400">Hourly breakdown of store volume</p>
      </div>
      
      <div className="flex-1 w-full min-h-[300px]">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
            <XAxis dataKey="time" stroke="rgba(255,255,255,0.5)" />
            <YAxis stroke="rgba(255,255,255,0.5)" />
            <Tooltip 
              contentStyle={{ backgroundColor: 'rgba(15,15,19,0.9)', borderColor: 'rgba(168,85,247,0.3)', borderRadius: '8px' }}
              itemStyle={{ color: '#fff' }}
            />
            <Line type="monotone" dataKey="visitors" stroke="#a855f7" strokeWidth={3} dot={{ r: 4, fill: '#a855f7' }} activeDot={{ r: 8 }} />
            <Line type="monotone" dataKey="conversion" stroke="#34d399" strokeWidth={3} dot={{ r: 4, fill: '#34d399' }} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </motion.div>
  );
}
