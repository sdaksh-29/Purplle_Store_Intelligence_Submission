/** @type {import('next').NextConfig} */
const nextConfig = {
  output: "standalone",
  experimental: {
    // any experimental features
  }
};

export default nextConfig;
