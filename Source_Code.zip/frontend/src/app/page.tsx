"use client";

import { useState, useEffect } from "react";
import { Users, Target, Clock, Activity } from "lucide-react";
import { MetricCard } from "@/components/MetricCard";
import { Leaderboard } from "@/components/Leaderboard";
import { Achievements } from "@/components/Achievements";
import { AIInsightsPanel } from "@/components/AIInsightsPanel";
import { TrafficChart } from "@/components/TrafficChart";
import { ZoneHeatmap } from "@/components/ZoneHeatmap";
import { AnomalyFeed } from "@/components/AnomalyFeed";

export default function Home() {
  const [metrics, setMetrics] = useState({
    visitors: 0,
    conversion_rate: 0.0,
    avg_dwell: 0.0,
    queue_depth: 0
  });

  useEffect(() => {
    fetch("http://localhost:8000/stores/store_1/metrics")
      .then(res => res.json())
      .then(data => setMetrics(data))
      .catch(console.error);
      
    // Poll every 10 seconds for metric updates
    const interval = setInterval(() => {
      fetch("http://localhost:8000/stores/store_1/metrics")
        .then(res => res.json())
        .then(data => setMetrics(data))
        .catch(console.error);
    }, 10000);
    
    return () => clearInterval(interval);
  }, []);

  return (
    <main className="min-h-screen p-6 md:p-12 lg:p-24 max-w-7xl mx-auto">
      <div className="flex justify-between items-end mb-12">
        <div>
          <h1 className="text-4xl md:text-5xl font-bold mb-2">Store Intelligence</h1>
          <p className="text-slate-400">Purplle Tech Challenge 2026 • Live Monitoring</p>
        </div>
        
        {/* Live Status indicator */}
        <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-sm font-semibold">
          <span className="relative flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
          </span>
          System Live
        </div>
      </div>

      {/* Main KPI Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <MetricCard
          title="Live Traffic Volume"
          value={metrics.visitors.toString()}
          icon={Users}
          trend="Real-time"
          trendUp={true}
          delay={0.1}
        />
        <MetricCard
          title="Conversion Rate"
          value={`${metrics.conversion_rate.toFixed(1)}%`}
          icon={Target}
          trend="Active"
          trendUp={true}
          delay={0.2}
          className="border-purplle-500/30"
        />
        <MetricCard
          title="Avg Dwell Time"
          value={`${metrics.avg_dwell.toFixed(1)}m`}
          icon={Clock}
          trend="Store-wide"
          trendUp={false}
          delay={0.3}
        />
        <MetricCard
          title="Live Queue Depth"
          value={metrics.queue_depth.toString()}
          icon={Activity}
          trend={metrics.queue_depth > 5 ? "High Traffic" : "Normal"}
          trendUp={metrics.queue_depth > 5}
          delay={0.4}
        />
      </div>

      {/* AI Insights Engine */}
      <div className="mb-8">
        <AIInsightsPanel />
      </div>

      {/* Real-time Charts & Feeds */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-8">
        <TrafficChart />
        <ZoneHeatmap />
        <AnomalyFeed />
      </div>

      {/* Gamification & Rankings */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Leaderboard />
        <Achievements />
      </div>
    </main>
  );
}
