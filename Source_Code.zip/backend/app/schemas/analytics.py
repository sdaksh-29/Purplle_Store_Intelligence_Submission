from pydantic import BaseModel, Field
from typing import List, Dict, Optional
from datetime import datetime

class IngestResponse(BaseModel):
    accepted: int = Field(..., description="Number of events successfully ingested")
    rejected: int = Field(..., description="Number of events rejected due to deduplication or validation failure")
    errors: List[str] = Field(default_factory=list, description="List of error messages for rejected events")

class MetricsResponse(BaseModel):
    visitors: int = Field(..., description="Total unique visitors")
    conversion_rate: float = Field(..., description="Percentage of visitors who reached the billing queue")
    avg_dwell_time: float = Field(..., description="Average store dwell time in seconds")
    queue_depth: int = Field(..., description="Current number of people in billing queue")
    abandonment_rate: float = Field(..., description="Percentage of people who abandoned the queue")

class FunnelStep(BaseModel):
    step: str
    count: int
    dropoff_rate: float

class FunnelResponse(BaseModel):
    steps: List[FunnelStep]

class HeatmapZone(BaseModel):
    zone_name: str
    visit_count: int
    avg_dwell: float
    avg_confidence: float

class HeatmapResponse(BaseModel):
    zones: List[HeatmapZone]

class AnomalySeverity(str, BaseModel):
    pass

class Anomaly(BaseModel):
    type: str = Field(..., description="e.g., Queue Spike, Conversion Drop, Dead Zone")
    severity: str = Field(..., description="INFO, WARN, CRITICAL")
    description: str
    suggested_action: str

class AnomaliesResponse(BaseModel):
    anomalies: List[Anomaly]

class HealthResponse(BaseModel):
    status: str
    last_event_timestamp: Optional[datetime] = None
    stale_feed_warnings: List[str] = Field(default_factory=list)
