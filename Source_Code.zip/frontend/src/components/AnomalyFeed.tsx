"use client";

import { motion } from "framer-motion";
import { AlertCircle, Activity } from "lucide-react";
import { useRealtime } from "@/hooks/useRealtime";

export function AnomalyFeed() {
  const { events, isConnected } = useRealtime();

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5, delay: 0.8 }}
      className="glass-card p-6 h-[400px] col-span-full lg:col-span-1 overflow-y-auto"
    >
      <div className="flex items-center justify-between mb-6 sticky top-0 bg-[var(--card-bg)]/80 backdrop-blur-md pb-2 z-10 border-b border-white/5">
        <h2 className="text-xl font-bold flex items-center gap-2">
          <Activity className="text-rose-400" /> Live Event Feed
        </h2>
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400">{isConnected ? 'Live' : 'Connecting...'}</span>
          <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-emerald-500 animate-pulse' : 'bg-rose-500'}`} />
        </div>
      </div>

      <div className="space-y-3">
        {events.length === 0 ? (
          <p className="text-sm text-slate-500 text-center mt-10">Waiting for live events...</p>
        ) : (
          events.map((event, idx) => (
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              key={event.event_id + idx}
              className="p-3 rounded-xl bg-white/5 border border-white/5 flex items-start gap-3 text-sm"
            >
              <div className="mt-0.5">
                {event.event_type === "ENTRY" ? (
                  <div className="w-2 h-2 rounded-full bg-emerald-400" />
                ) : event.event_type.includes("QUEUE") ? (
                  <div className="w-2 h-2 rounded-full bg-amber-400" />
                ) : (
                  <div className="w-2 h-2 rounded-full bg-blue-400" />
                )}
              </div>
              <div className="flex-1">
                <p className="font-semibold text-slate-200">
                  {event.event_type.replace(/_/g, ' ')}
                </p>
                <p className="text-xs text-slate-400">Visitor: {event.visitor_id.substring(0,8)}...</p>
              </div>
              <span className="text-[10px] text-slate-500">
                {new Date(event.timestamp).toLocaleTimeString()}
              </span>
            </motion.div>
          ))
        )}
      </div>
    </motion.div>
  );
}
