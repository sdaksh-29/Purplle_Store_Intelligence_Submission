import time
from typing import Dict, Tuple
import logging
from app.schemas.event import StoreEvent

logger = logging.getLogger(__name__)

class EventValidator:
    """
    Validates and deduplicates events.
    """
    def __init__(self, deduplication_window_seconds: int = 5):
        # Stores signature -> timestamp for deduplication
        self._seen_events: Dict[str, float] = {}
        self.deduplication_window = deduplication_window_seconds

    def _generate_signature(self, event: StoreEvent) -> str:
        """
        Generate a unique signature for deduplication.
        For example, if the same person emits ZONE_ENTER for the same zone 
        twice within 5 seconds, it's likely a bounding box jitter/duplicate.
        """
        zone = event.metadata.get("zone", "") if event.metadata else ""
        return f"{event.visitor_id}_{event.event_type.value}_{event.camera_id}_{zone}"

    def clean_stale_records(self, current_time: float):
        """
        Remove old signatures to prevent memory leaks over long running times.
        """
        keys_to_delete = []
        for sig, ts in self._seen_events.items():
            if current_time - ts > self.deduplication_window:
                keys_to_delete.append(sig)
        for k in keys_to_delete:
            del self._seen_events[k]

    def process(self, event: StoreEvent) -> bool:
        """
        Validates the event and checks for duplicates.
        Returns True if the event is valid and novel, False if duplicate/invalid.
        """
        # 1. Pydantic already handles structural validation (types, bounds, UUIDs).
        
        # 2. Deduplication Logic
        current_time = time.time()
        self.clean_stale_records(current_time)
        
        signature = self._generate_signature(event)
        
        if signature in self._seen_events:
            logger.debug(f"Deduplicated event: {signature}")
            return False
            
        # Register new signature
        self._seen_events[signature] = current_time
        return True

validator = EventValidator()
