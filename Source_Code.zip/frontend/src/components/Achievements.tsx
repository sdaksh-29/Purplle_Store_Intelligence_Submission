"use client";

import { motion } from "framer-motion";
import { Award, Zap, TrendingUp, ShieldCheck } from "lucide-react";
import { cn } from "@/lib/utils";

const BADGES = [
  { id: 1, title: "Peak Performer", desc: "Highest conversion store this week", icon: Award, color: "text-amber-400", bg: "bg-amber-400/10", border: "border-amber-400/20" },
  { id: 2, title: "Traffic Master", desc: "Managed 500+ visitors flawlessly", icon: Zap, color: "text-blue-400", bg: "bg-blue-400/10", border: "border-blue-400/20" },
  { id: 3, title: "Queue Zero", desc: "No queue exceeded 5 mins today", icon: ShieldCheck, color: "text-emerald-400", bg: "bg-emerald-400/10", border: "border-emerald-400/20" },
];

export function Achievements() {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5, delay: 0.4 }}
      className="glass-card p-6 col-span-full lg:col-span-2"
    >
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold flex items-center gap-2">
          <Award className="text-purplle-400" /> Store Achievements
        </h2>
        <span className="text-xs font-semibold px-3 py-1 bg-purplle-500/20 text-purplle-300 rounded-full">
          Level 42 Store
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {BADGES.map((badge, idx) => {
          const Icon = badge.icon;
          return (
            <motion.div
              key={badge.id}
              whileHover={{ scale: 1.05, y: -5 }}
              className={cn("p-4 rounded-xl border flex flex-col items-center text-center cursor-pointer transition-all", badge.bg, badge.border)}
            >
              <div className="mb-3 p-3 bg-white/10 rounded-full backdrop-blur-md shadow-lg">
                <Icon className={cn("w-8 h-8", badge.color)} />
              </div>
              <h3 className="font-bold text-sm mb-1">{badge.title}</h3>
              <p className="text-xs text-slate-400">{badge.desc}</p>
            </motion.div>
          );
        })}
      </div>
    </motion.div>
  );
}
