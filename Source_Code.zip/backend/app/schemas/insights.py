from pydantic import BaseModel
from typing import List, Dict, Any

class StoreHealthScore(BaseModel):
    score: int  # 0-100
    grade: str  # A, B, C, D, F
    breakdown: Dict[str, float]

class JourneyPath(BaseModel):
    path: List[str]
    count: int
    conversion_rate: float

class CustomerJourneyResponse(BaseModel):
    common_paths: List[JourneyPath]

class ForecastResponse(BaseModel):
    peak_traffic_prediction_time: str
    predicted_queue_depth_next_15m: int
    expected_eod_conversion_rate: float

class ZonePerformance(BaseModel):
    zone_name: str
    rank: int
    score: float
    status: str  # e.g., 'High Performing', 'Dead Zone', 'Bottleneck'
    revenue_opportunity_flag: bool

class PerformanceRankingResponse(BaseModel):
    zones: List[ZonePerformance]

class StaffEfficiency(BaseModel):
    staff_to_customer_ratio: float
    staff_utilization_score: float

class AIInsight(BaseModel):
    insight_text: str
    category: str  # e.g., 'Operations', 'Sales', 'Layout'

class InsightsResponse(BaseModel):
    health_score: StoreHealthScore
    forecasts: ForecastResponse
    staff_efficiency: StaffEfficiency
    ai_insights: List[AIInsight]
