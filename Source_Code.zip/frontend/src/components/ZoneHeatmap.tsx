"use client";

import { motion } from "framer-motion";
import { useRealtime } from "@/hooks/useRealtime";

export function ZoneHeatmap() {
  const { events } = useRealtime();
  
  // Real-time animation trigger when an event happens in a zone
  const hasRecentEvent = (zone: string) => {
    return events.some(e => e.metadata?.zone?.includes(zone) && e.event_type === "ZONE_ENTER");
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.7 }}
      className="glass-card p-6 h-[400px] col-span-full lg:col-span-1"
    >
      <h2 className="text-xl font-bold mb-6">Live Store Heatmap</h2>
      
      <div className="relative w-full h-[280px] bg-slate-900/50 rounded-xl border border-white/5 p-4 grid grid-cols-2 grid-rows-3 gap-2">
        {/* Mock Store Layout */}
        <div className={`rounded-lg p-2 flex flex-col justify-end transition-colors duration-500 ${hasRecentEvent('Entry') ? 'bg-purplle-500/40 border-purplle-400' : 'bg-purplle-500/10'} border border-white/10`}>
          <span className="text-xs font-semibold">Entry / Browsing</span>
        </div>
        <div className={`rounded-lg p-2 flex flex-col justify-end transition-colors duration-500 ${hasRecentEvent('Skincare') ? 'bg-pink-500/40 border-pink-400' : 'bg-pink-500/10'} border border-white/10 row-span-2`}>
          <span className="text-xs font-semibold">Skincare Zone (Hot)</span>
        </div>
        <div className={`rounded-lg p-2 flex flex-col justify-end transition-colors duration-500 ${hasRecentEvent('Fragrance') ? 'bg-amber-500/40 border-amber-400' : 'bg-amber-500/10'} border border-white/10`}>
          <span className="text-xs font-semibold">Fragrance Bar</span>
        </div>
        <div className={`rounded-lg p-2 flex flex-col justify-end transition-colors duration-500 ${hasRecentEvent('Makeup') ? 'bg-blue-500/40 border-blue-400' : 'bg-blue-500/10'} border border-white/10 col-span-2`}>
          <span className="text-xs font-semibold">Makeup Counters</span>
        </div>
        
        {/* Animated Blip representing active tracking */}
        <motion.div 
          animate={{ scale: [1, 1.5, 1], opacity: [0.5, 1, 0.5] }} 
          transition={{ repeat: Infinity, duration: 2 }}
          className="absolute top-1/4 left-1/3 w-3 h-3 bg-white rounded-full shadow-[0_0_10px_#fff]" 
        />
      </div>
    </motion.div>
  );
}
