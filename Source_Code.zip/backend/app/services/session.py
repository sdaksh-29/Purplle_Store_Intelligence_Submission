import uuid
from datetime import datetime, timedelta
from typing import Dict, Optional, Tuple
import numpy as np
from app.cv.reid import compute_similarity

class VisitorSession:
    def __init__(self, visitor_id: str, initial_embedding: np.ndarray, timestamp: datetime):
        self.visitor_id = visitor_id
        self.embeddings = [initial_embedding]  # Store history of embeddings to improve matching
        self.first_seen = timestamp
        self.last_seen = timestamp
        self.is_staff = False
        self.camera_tracks: Dict[str, int] = {}  # camera_id -> track_id
        self.in_store = True

    def update(self, embedding: np.ndarray, timestamp: datetime, camera_id: str, track_id: int):
        self.last_seen = timestamp
        self.camera_tracks[camera_id] = track_id
        
        # Keep recent embeddings (up to 5) for robustness
        self.embeddings.append(embedding)
        if len(self.embeddings) > 5:
            self.embeddings.pop(0)

    def get_aggregate_embedding(self) -> np.ndarray:
        if not self.embeddings:
            return np.zeros(2048)
        avg_emb = np.mean(self.embeddings, axis=0)
        norm = np.linalg.norm(avg_emb)
        if norm > 0:
            return avg_emb / norm
        return avg_emb

class SessionManager:
    def __init__(self, similarity_threshold: float = 0.75, session_timeout_mins: int = 30):
        self.active_sessions: Dict[str, VisitorSession] = {}
        self.similarity_threshold = similarity_threshold
        self.session_timeout = timedelta(minutes=session_timeout_mins)

    def match_or_create(self, camera_id: str, track_id: int, embedding: np.ndarray, timestamp: datetime) -> Tuple[VisitorSession, bool]:
        """
        Match an embedding to an existing session or create a new one.
        Returns the session and a boolean indicating if it's a new session.
        """
        best_match_id = None
        best_score = -1.0

        # First, check if we already track this track_id in this camera
        for s_id, session in self.active_sessions.items():
            if session.camera_tracks.get(camera_id) == track_id and session.in_store:
                session.update(embedding, timestamp, camera_id, track_id)
                return session, False

        # If not, try to match via Re-ID embedding
        for s_id, session in self.active_sessions.items():
            if not session.in_store:
                # Could be a REENTRY if time is within threshold or same day
                pass
                
            agg_emb = session.get_aggregate_embedding()
            score = compute_similarity(agg_emb, embedding)
            if score > best_score:
                best_score = score
                best_match_id = s_id

        if best_score >= self.similarity_threshold and best_match_id:
            # Matched existing session (Cross-camera deduplication or Re-entry)
            session = self.active_sessions[best_match_id]
            is_new = False
            if not session.in_store:
                session.in_store = True
                # It's a re-entry
            session.update(embedding, timestamp, camera_id, track_id)
            return session, False
        else:
            # Create new session
            visitor_id = str(uuid.uuid4())
            new_session = VisitorSession(visitor_id, embedding, timestamp)
            new_session.camera_tracks[camera_id] = track_id
            self.active_sessions[visitor_id] = new_session
            return new_session, True

    def mark_exit(self, visitor_id: str):
        if visitor_id in self.active_sessions:
            self.active_sessions[visitor_id].in_store = False

    def cleanup_stale_sessions(self, current_time: datetime):
        # Optional: remove very old sessions from memory to save space
        pass
